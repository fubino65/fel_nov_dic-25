//COSTANTI

//ELEMENTI DEL DOM

const inizio = document.getElementById("inizio");
const fine = document.getElementById("fine");
const andiamoInPausa= document.getElementById("clicca")
const ripartePausa= document.getElementById("riClicca")

const pausa = new Date()
const finePausa = new Date(pausa);
finePausa.setMinutes(finePausa.getMinutes() + 15);

let timeOptions = {
    hour: "2-digit",
    minute: "2-digit"
}

console.log(pausa.toLocaleTimeString("it-IT", timeOptions));
console.log(finePausa.toLocaleTimeString("it-IT", timeOptions));

//GESTIONE DEGLI EVENTI

andiamoInPausa.addEventListener("click", function () {
console.log("CLICK INTERCETTATO")
const pausa = new Date()
const finePausa = new Date(pausa);
finePausa.setMinutes(finePausa.getMinutes() + 15);

console.log(`la pausa inizia alle ${pausa.getHours()}:${pausa.getMinutes()} e finisce alle ${pausa.getHours()}:${pausa.getMinutes() + 15}`);

inizio.textContent = pausa.toLocaleTimeString("it-IT", timeOptions);
fine.textContent = finePausa.toLocaleTimeString("it-IT", timeOptions);
})

ripartePausa.addEventListener("click", function() {
    console.log("CLICK INTERCETTATO")
    inizio.textContent = "";
    fine.textContent = ""
}
)