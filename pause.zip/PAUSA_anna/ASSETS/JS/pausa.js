//COSTANTI


//ELEMENTI DEL DOM
const spanInizioPausa = document.getElementById("inizio");
const spanFinePausa = document.getElementById("fine");
const siamoInPausa = document.querySelector("#pausa h3");


//ALTRE VARIABILI
let timeOptions ={
  hour: "2-digit",
  minute: "2-digit"
  
}


//GESTIONE DEGLI EVENTI

//il button fa partire gli orari di inizio e fine pausa
const startButton = document.getElementById("startBtn");
startButton.addEventListener("click", ()=>{
    inizioPausa = new Date();
    finePausa = new Date();
    finePausa.setMinutes(inizioPausa.getMinutes() +15);
    spanInizioPausa.textContent = inizioPausa.toLocaleTimeString("it-IT", timeOptions);
    spanFinePausa.textContent = finePausa.toLocaleTimeString("it-IT", timeOptions);
    siamoInPausa.classList.remove("nascosto");
})







//FUNZIONI UTILI
