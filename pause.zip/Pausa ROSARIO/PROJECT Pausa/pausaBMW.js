<script>
  document.querySelector(".clicca").addEventListener("click", function() {
    window.location.href = "pausa.html"
  });
</script>

