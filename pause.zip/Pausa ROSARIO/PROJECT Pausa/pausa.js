// Consigliata da IA in modo che non restituisca NaN
window.addEventListener("DOMContentLoaded", function () {
  const durataMinuti = 15;

  // Selettori HTML/CSS
  const dataOggi = document.querySelector(".data");              
  const mostraTempo = document.querySelector(".mostraTempo");    
  const statoTempo = document.querySelector(".statoTempo");      

  const orari = document.querySelectorAll(".valoreOra");         
  const startOra = orari[0];                                     
  const endOra = orari[1];                                       

  const btnStart = document.querySelector(".bStart");
  const btnStop = document.querySelector(".bStop");
  const btnReset = document.querySelector(".bReset");

  // timer
  let intervallo = null;
  let tempoInSecondi = durataMinuti * 60;
  let timerAttivo = false;

  // Formatto i secondi come MM:SS usando Date 
  function formattaOrarioDaZero(secondi) {
    const fittizia = new Date(secondi * 1000);      // 0 → 1970-01-01T00:00:00.000Z
    return fittizia.toISOString().substring(14, 19); // prendo "MM:SS"
  }

  // Mostro la data di oggi con toLocaleDateString
  function mostraDataOggi() {
    const adesso = new Date();
    dataOggi.textContent = adesso.toLocaleDateString("it-IT");
  }

  // Avvia il timer
  function avvia() {
    if (timerAttivo) return; // evita doppi click
    timerAttivo = true;

    statoTempo.textContent = "In corso...";
    mostraDataOggi();

    // Inizio pausa
    const inizioPausa = new Date();
    startOra.textContent = inizioPausa.toLocaleTimeString("it-IT", {
      hour: "2-digit",
      minute: "2-digit",
    });

  
    const finePausa = new Date(inizioPausa);
    finePausa.setMinutes(inizioPausa.getMinutes() + durataMinuti);
    endOra.textContent = finePausa.toLocaleTimeString("it-IT", {
      hour: "2-digit",
      minute: "2-digit",
    });

    // Conto alla rovescia 
    intervallo = setInterval(() => {
      tempoInSecondi--;

      mostraTempo.textContent = formattaOrarioDaZero(tempoInSecondi);

      if (tempoInSecondi <= 0) {
        clearInterval(intervallo);
        mostraTempo.textContent = "00:00";
        statoTempo.textContent = "Pausa terminata, la prof Grignaschi è tornata!";
        timerAttivo = false;
      }
    }, 1000);
  }

  // Stop
  function ferma() {
    clearInterval(intervallo);
    statoTempo.textContent = "In pausa...";
    timerAttivo = false;
  }

  // Reset
  function resetta() {
    clearInterval(intervallo);
    tempoInSecondi = durataMinuti * 60;
    mostraTempo.textContent = formattaOrarioDaZero(tempoInSecondi);
    statoTempo.textContent = "Clicca per avviare il timer...";
    startOra.textContent = "--:--";
    endOra.textContent = "--:--";
    timerAttivo = false;
  }

  //  Eventilis bottoni
  btnStart.addEventListener("click", avvia);
  btnStop.addEventListener("click", ferma);
  btnReset.addEventListener("click", resetta);

  // Imposto il valore iniziale del timer in base a durataMinuti
  mostraTempo.textContent = formattaOrarioDaSecondi(tempoInSecondi);
});

