document.addEventListener('DOMContentLoaded', function() {
    // Elementi DOM
    const timerDisplay = document.getElementById('timerDisplay');
    const timerDigits = timerDisplay.querySelector('.timer-digits');
    const timerButton = document.getElementById('timerButton');
    const autoMessage = document.getElementById('autoMessage');
    const messageIcon = document.getElementById('messageIcon');
    const messageText = document.getElementById('messageText');
    const bubbleEffect = document.getElementById('bubbleEffect');
    const pauseBtn = document.getElementById('pauseBtn');
    const resetBtn = document.getElementById('resetBtn');
    const settingsBtn = document.getElementById('settingsBtn');
    const settingsPanel = document.getElementById('settingsPanel');
    const closeSettings = document.getElementById('closeSettings');
    const themeToggle = document.getElementById('themeToggle');
    const themeText = themeToggle.querySelector('.theme-text');
    const themeIcon = themeToggle.querySelector('i');
    const bgSpeedSlider = document.getElementById('bgSpeed');
    const bgSpeedValue = document.getElementById('bgSpeedValue');
    const autoStartToggle = document.getElementById('autoStart');
    
    const startSound = new Audio();
    startSound.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';
    
    const endSound = new Audio();
    endSound.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEAQB8AAEAfAAABAAgAZGF0YYQAAAAA=';

    function isMobile() {
        return window.innerWidth <= 1024 || 
            /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    if (isMobile()) {
        const blob = document.getElementById('blob-cursor');
        if (blob) {
            blob.style.display = 'none';
            blob.style.opacity = '0';
            blob.style.visibility = 'hidden';
        }
        
        const originalAddEventListener = document.addEventListener;
        document.addEventListener = function(type, listener, options) {
            if (type === 'mousemove' && isMobile()) {
                return;
            }
            originalAddEventListener.call(document, type, listener, options);
        };
    }

    function playStartSound() {
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            gainNode.gain.value = 0.1;
            
            oscillator.start();
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
            oscillator.stop(audioContext.currentTime + 0.1);
        } catch (e) {
            console.log("Suono fallback non supportato");
        }
    }

    function playEndSound() {
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 1200;
            oscillator.type = 'sine';
            gainNode.gain.value = 0.1;
            
            oscillator.start();
            
            for(let i = 0; i < 3; i++) {
                setTimeout(() => {
                    gainNode.gain.cancelScheduledValues(audioContext.currentTime);
                    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
                }, i * 200);
            }
            
            oscillator.stop(audioContext.currentTime + 0.6);
        } catch (e) {
            console.log("Suono fallback non supportato");
        }
    }

    // Funzione per formattare l'ora in formato HH:MM
    function formatTime(date) {
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    let timerActive = false;
    let timerPaused = false;
    let countdown;
    let timeLeft = 15 * 60;
    let totalTime = 15 * 60;
    let bgSpeed = 5;
    let noiseIntensity = 5;
    let startTime = null;
    let endTime = null;
    let messageTimeout = null;
    let timeMessageTimeout = null;
    
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeUI(savedTheme);
    
    bgSpeedSlider.value = 5;
    bgSpeedValue.textContent = 5;
    updateBackgroundSpeed(5);
    
    setTimeout(() => {
        if (autoStartToggle.checked) {
            autoStartTimer();
        }
    }, 3000);
    
    bgSpeedSlider.addEventListener('input', function() {
        bgSpeed = parseInt(this.value);
        bgSpeedValue.textContent = bgSpeed;
        updateBackgroundSpeed(bgSpeed);
        createSpeedChangeEffect();
    });
    
    themeToggle.addEventListener('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.documentElement.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
        document.documentElement.setAttribute('data-theme', newTheme);
        
        setTimeout(() => {
            document.documentElement.style.transition = '';
        }, 500);
        
        localStorage.setItem('theme', newTheme);
        updateThemeUI(newTheme);
        createThemeChangeEffect(newTheme);
    });
    
    timerButton.addEventListener('click', function() {
        if (!timerActive) {
            startTimer();
        } else if (timerActive && !timerPaused) {
            pauseTimer();
        } else if (timerActive && timerPaused) {
            resumeTimer();
        }
    });
    
    pauseBtn.addEventListener('click', function() {
        if (timerActive && !timerPaused) {
            pauseTimer();
        }
    });
    
    resetBtn.addEventListener('click', function() {
        resetTimer();
    });
    
    settingsBtn.addEventListener('click', function() {
        if (settingsPanel.classList.contains('show')) {
            settingsPanel.classList.remove('show');
            const settingsContent = settingsPanel.querySelector('.settings-content');
            settingsContent.style.transition = '';
            settingsContent.style.opacity = '';
            settingsContent.style.transform = '';
        } else {
            settingsPanel.classList.add('show');
            createSettingsOpenEffect();
        }
    });

    closeSettings.addEventListener('click', function() {
        settingsPanel.classList.remove('show');
        const settingsContent = settingsPanel.querySelector('.settings-content');
        settingsContent.style.transition = '';
        settingsContent.style.opacity = '';
        settingsContent.style.transform = '';
    });

    window.addEventListener('click', function(event) {
        if (event.target === settingsPanel) {
            settingsPanel.classList.remove('show');
            const settingsContent = settingsPanel.querySelector('.settings-content');
            settingsContent.style.transition = '';
            settingsContent.style.opacity = '';
            settingsContent.style.transform = '';
        }
    });
    
    function autoStartTimer() {
        createBubbleEffect();
        playStartSound();
        
        setTimeout(() => {
            startTimer(true);
        }, 800);
    }
    
    function startTimer(isAuto = false) {
        if (timerActive) return;
        
        timerActive = true;
        timerPaused = false;
        timerDisplay.parentElement.classList.add('timer-running');
        
        createBubbleEffect();
        playStartSound();
        createRippleEffect(timerButton);
        
        updateButtonText();
        
        // Imposta gli orari di inizio e fine
        startTime = new Date();
        endTime = new Date(startTime.getTime() + 15 * 60000);
        
        // Mostra messaggio di avvio
        showStartMessage(isAuto);

        countdown = setInterval(() => {
            if (!timerPaused) {
                timeLeft--;
                updateTimerDisplay();
                
                if (timeLeft <= 0) {
                    timerComplete();
                }
            }
        }, 1000);
    }
    
    // Mostra messaggio di avvio (automatico o manuale)
    function showStartMessage(isAuto) {
        // Pulisci timeout precedenti
        clearAllMessageTimeouts();
        
        // Imposta il contenuto del messaggio
        if (isAuto) {
            messageIcon.className = 'fas fa-robot';
            messageText.textContent = 'Timer avviato automaticamente. Buona pausa!';
        } else {
            messageIcon.className = 'fas fa-play-circle';
            messageText.textContent = 'Timer avviato. Buona pausa!';
        }
        
        // Rimuovi classe time-message se presente
        autoMessage.querySelector('.message-bubble').classList.remove('time-message');
        
        // Assicurati che il messaggio sia visibile e resetta le transizioni
        autoMessage.style.transition = 'none';
        autoMessage.style.opacity = '0';
        autoMessage.style.transform = 'translateY(20px)';
        autoMessage.style.display = 'block';
        
        // Forza un reflow
        void autoMessage.offsetWidth;
        
        // Applica la transizione e mostra
        autoMessage.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
        setTimeout(() => {
            autoMessage.style.opacity = '1';
            autoMessage.style.transform = 'translateY(0)';
        }, 10);
        
        // Dopo 3 secondi, nascondi il messaggio di avvio e mostra quello con gli orari
        messageTimeout = setTimeout(() => {
            hideStartMessageAndShowTime();
        }, 3000);
    }
    
    // Nascondi messaggio di avvio e mostra quello con gli orari
    function hideStartMessageAndShowTime() {
        // Nascondi prima il messaggio
        autoMessage.style.opacity = '0';
        autoMessage.style.transform = 'translateY(20px)';
        
        // Dopo l'animazione di uscita, mostra il messaggio con gli orari
        setTimeout(() => {
            showTimeMessage();
        }, 500);
    }
    
    // Mostra messaggio con gli orari
    function showTimeMessage() {
        if (!startTime || !endTime) return;
        
        // Pulisci eventuali timeout
        clearAllMessageTimeouts();
        
        // Formatta gli orari
        const startFormatted = formatTime(startTime);
        const endFormatted = formatTime(endTime);
        
        // Aggiorna il contenuto del messaggio
        messageIcon.className = 'fas fa-clock';
        messageText.innerHTML = `
            <div class="time-text">
                <div class="time-label">Siamo in pausa</div>
                <div class="time-range">dalle ${startFormatted} alle ${endFormatted}</div>
            </div>
        `;
        
        // Aggiungi classe per stile speciale
        autoMessage.querySelector('.message-bubble').classList.add('time-message');
        
        // Mostra il messaggio con animazione
        autoMessage.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
        autoMessage.style.opacity = '1';
        autoMessage.style.transform = 'translateY(0)';
        autoMessage.style.display = 'block';
        
        // Il messaggio rimarrà visibile fino alla fine del timer
    }
    
    // Nascondi completamente il messaggio
    function hideMessage() {
        clearAllMessageTimeouts();
        
        autoMessage.style.opacity = '0';
        autoMessage.style.transform = 'translateY(20px)';
        
        // Dopo l'animazione, nascondi completamente
        timeMessageTimeout = setTimeout(() => {
            autoMessage.style.display = 'none';
            // Rimuovi classe time-message per futuri utilizzi
            autoMessage.querySelector('.message-bubble').classList.remove('time-message');
        }, 500);
    }
    
    // Pulisci tutti i timeout dei messaggi
    function clearAllMessageTimeouts() {
        if (messageTimeout) {
            clearTimeout(messageTimeout);
            messageTimeout = null;
        }
        
        if (timeMessageTimeout) {
            clearTimeout(timeMessageTimeout);
            timeMessageTimeout = null;
        }
    }
    
    function pauseTimer() {
        timerPaused = true;
        timerDisplay.parentElement.classList.remove('timer-running');
        updateButtonText();
        createPauseEffect();
    }
    
    function resumeTimer() {
        timerPaused = false;
        timerDisplay.parentElement.classList.add('timer-running');
        updateButtonText();
        createResumeEffect();
    }
    
    function resetTimer() {
        clearInterval(countdown);
        timerActive = false;
        timerPaused = false;
        timeLeft = 15 * 60;
        totalTime = 15 * 60;
        startTime = null;
        endTime = null;
        
        updateTimerDisplay();
        updateButtonText();
        timerDisplay.parentElement.classList.remove('timer-running');
        
        // Nascondi tutti i messaggi
        hideMessage();
        
        createResetEffect();
    }
    
    function timerComplete() {
        clearInterval(countdown);
        timerActive = false;
        timerPaused = false;
        
        playEndSound();
        createCompletionEffect();
        
        // Nascondi il messaggio degli orari
        setTimeout(() => {
            hideMessage();
        }, 1000);
        
        showNotification();
        
        setTimeout(() => {
            if (autoStartToggle.checked) {
                timeLeft = 15 * 60;
                totalTime = 15 * 60;
                updateTimerDisplay();
                autoStartTimer();
            } else {
                updateButtonText();
                timerDisplay.parentElement.classList.remove('timer-running');
            }
        }, 3000);
    }
    
    function updateTimerDisplay() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        
        timerDigits.textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        const progress = (timeLeft / totalTime) * 100;
        updateTimerVisualProgress(progress);
    }
    
    function updateTimerVisualProgress(progress) {
        const color1 = '#007AFF';  
        const color2 = '#5ac8fa';  
        
        if (timerActive && !timerPaused) {
            timerButton.style.background = `linear-gradient(135deg, ${color1}, ${color2})`;
        }
    }
    
    function updateButtonText() {
        const buttonIcon = timerButton.querySelector('i');
        const buttonText = timerButton.querySelector('.button-text');
        
        if (!timerActive) {
            buttonIcon.className = 'fas fa-play-circle';
            buttonText.textContent = 'Avvia Pausa 15 Minuti';
            timerButton.style.background = 'linear-gradient(135deg, var(--color-accent), var(--color-accent-light))';
        } else if (timerActive && !timerPaused) {
            buttonIcon.className = 'fas fa-pause-circle';
            buttonText.textContent = 'Pausa Timer';
        } else if (timerActive && timerPaused) {
            buttonIcon.className = 'fas fa-play-circle';
            buttonText.textContent = 'Riprendi Timer';
        }
    }
    
    function updateThemeUI(theme) {
        if (theme === 'dark') {
            themeIcon.className = 'fas fa-sun';
            themeText.textContent = 'Chiaro';
        } else {
            themeIcon.className = 'fas fa-moon';
            themeText.textContent = 'Scuro';
        }
    }
    
    function updateBackgroundSpeed(speed) {
        document.documentElement.style.setProperty('--bg-speed', speed);
        
        document.querySelectorAll('.blob, .drop').forEach(el => {
            el.style.animationDuration = `calc(${25/speed}s)`;
        });
    }
    
    function createBubbleEffect() {
        bubbleEffect.style.width = '10px';
        bubbleEffect.style.height = '10px';
        bubbleEffect.style.opacity = '0.8';
        bubbleEffect.style.transition = 'none';
        
        setTimeout(() => {
            bubbleEffect.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
            bubbleEffect.style.width = '250px';
            bubbleEffect.style.height = '250px';
            bubbleEffect.style.opacity = '0';
        }, 10);
        
        setTimeout(() => {
            bubbleEffect.style.transition = 'none';
            bubbleEffect.style.width = '10px';
            bubbleEffect.style.height = '10px';
            bubbleEffect.style.opacity = '0';
        }, 600);
    }
    
    function createRippleEffect(element) {
        const ripple = document.createElement('div');
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.background = 'radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%)';
        ripple.style.pointerEvents = 'none';
        ripple.style.zIndex = '1';
        
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        ripple.style.width = `${size}px`;
        ripple.style.height = `${size}px`;
        ripple.style.left = `${x - size/2}px`;
        ripple.style.top = `${y - size/2}px`;
        
        document.body.appendChild(ripple);
        
        const animation = ripple.animate([
            { transform: 'scale(0.5)', opacity: 1 },
            { transform: 'scale(2)', opacity: 0 }
        ], {
            duration: 600,
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
        });
        
        animation.onfinish = () => ripple.remove();
    }
    
    function createCompletionEffect() {
        const timerContainer = timerDisplay.parentElement;
        
        for (let i = 0; i < 20; i++) {
            createParticle(timerContainer, i);
        }
        
        timerDisplay.style.animation = 'pulseTimer 0.5s 3';
        setTimeout(() => {
            timerDisplay.style.animation = '';
        }, 1500);
        
        createWaveEffect(timerContainer);
    }
    
    function createParticle(container, index) {
        const particle = document.createElement('div');
        particle.style.position = 'absolute';
        particle.style.width = `${8 + Math.random() * 6}px`;
        particle.style.height = particle.style.width;
        particle.style.borderRadius = '50%';
        particle.style.background = 'radial-gradient(circle, var(--color-accent), var(--color-accent-light))';
        particle.style.zIndex = '100';
        particle.style.pointerEvents = 'none';
        
        const rect = container.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        particle.style.left = `${x}px`;
        particle.style.top = `${y}px`;
        
        document.body.appendChild(particle);
        
        const angle = (index / 20) * Math.PI * 2;
        const speed = 2 + Math.random() * 3;
        const distance = 50 + Math.random() * 100;
        
        const animation = particle.animate([
            { 
                transform: 'translate(0, 0) scale(1)', 
                opacity: 1 
            },
            { 
                transform: `translate(${Math.cos(angle) * distance}px, ${Math.sin(angle) * distance}px) scale(0)`, 
                opacity: 0 
            }
        ], {
            duration: 1000 + Math.random() * 500,
            easing: 'cubic-bezier(0.2, 0, 0.8, 1)'
        });
        
        animation.onfinish = () => particle.remove();
    }
    
    function createWaveEffect(container) {
        const wave = document.createElement('div');
        wave.style.position = 'absolute';
        wave.style.borderRadius = '50%';
        wave.style.border = '2px solid var(--color-accent)';
        wave.style.pointerEvents = 'none';
        wave.style.zIndex = '99';
        
        const rect = container.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        wave.style.width = `${size}px`;
        wave.style.height = `${size}px`;
        wave.style.left = `${x - size/2}px`;
        wave.style.top = `${y - size/2}px`;
        
        document.body.appendChild(wave);
        
        const animation = wave.animate([
            { 
                transform: 'scale(0.5)', 
                opacity: 0.8,
                borderWidth: '2px'
            },
            { 
                transform: 'scale(3)', 
                opacity: 0,
                borderWidth: '1px'
            }
        ], {
            duration: 1500,
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
        });
        
        animation.onfinish = () => wave.remove();
    }
    
    function createThemeChangeEffect(theme) {
        document.body.style.overflow = 'hidden';
        
        const transitionOverlay = document.createElement('div');
        transitionOverlay.style.position = 'fixed';
        transitionOverlay.style.top = '0';
        transitionOverlay.style.left = '0';
        transitionOverlay.style.width = '100%';
        transitionOverlay.style.height = '100%';
        transitionOverlay.style.background = theme === 'dark' ? '#000' : '#fff';
        transitionOverlay.style.zIndex = '9999';
        transitionOverlay.style.opacity = '0';
        transitionOverlay.style.pointerEvents = 'none';
        
        document.body.appendChild(transitionOverlay);
        
        const animation = transitionOverlay.animate([
            { opacity: 0 },
            { opacity: 0.7 },
            { opacity: 0 }
        ], {
            duration: 500,
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
        });
        
        animation.onfinish = () => {
            transitionOverlay.remove();
            document.body.style.overflow = '';
        };
    }
    
    function createSpeedChangeEffect() {
        const blobs = document.querySelectorAll('.blob');
        blobs.forEach(blob => {
            blob.style.animationPlayState = 'paused';
            void blob.offsetWidth;
            blob.style.animationPlayState = 'running';
        });
    }
    
    function createSettingsOpenEffect() {
        const settingsContent = settingsPanel.querySelector('.settings-content');
        settingsContent.style.opacity = '0';
        settingsContent.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            settingsContent.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
            settingsContent.style.opacity = '1';
            settingsContent.style.transform = 'translateY(0)';
        }, 100);
    }
    
    function createPauseEffect() {
        const timerContainer = timerDisplay.parentElement;
        timerContainer.style.transition = 'transform 0.3s ease';
        timerContainer.style.transform = 'scale(0.95)';
        
        setTimeout(() => {
            timerContainer.style.transform = 'scale(1)';
        }, 300);
    }
    
    function createResumeEffect() {
        const timerContainer = timerDisplay.parentElement;
        timerContainer.style.transition = 'transform 0.3s ease';
        timerContainer.style.transform = 'scale(1.05)';
        
        setTimeout(() => {
            timerContainer.style.transform = 'scale(1)';
        }, 300);
    }
    
    function createResetEffect() {
        const timerContainer = timerDisplay.parentElement;
        timerContainer.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
        timerContainer.style.transform = 'rotate(360deg)';
        
        setTimeout(() => {
            timerContainer.style.transform = 'rotate(0deg)';
        }, 500);
    }
    
    function showNotification() {
        if (Notification.permission === 'granted') {
            new Notification('Timer Completato!', {
                body: 'La tua pausa di 15 minuti è terminata.',
                icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="%23007AFF"/></svg>',
                tag: 'timer-notification'
            });
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    showNotification();
                }
            });
        }
    }
    
    if ('Notification' in window) {
        Notification.requestPermission();
    }
    
    document.querySelectorAll('.glass-header, .glass-card').forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            el.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, index * 200);
    });

    // Effetto cursore personalizzato
    let blob = document.getElementById('blob');
    if (!blob) {
        blob = document.createElement('div');
        blob.id = 'blob';
        blob.className = 'blob-cursor';
        document.body.appendChild(blob);
    }
    
    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let blobX = mouseX;
    let blobY = mouseY;
    let velocityX = 0;
    let velocityY = 0;
    let prevX = mouseX;
    let prevY = mouseY;

    setTimeout(() => {
        blob.style.opacity = '1';
    }, 100);

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        velocityX = mouseX - prevX;
        velocityY = mouseY - prevY;
        
        prevX = mouseX;
        prevY = mouseY;
    });

    function animateBlob() {
        const dx = mouseX - blobX;
        const dy = mouseY - blobY;
        
        blobX += dx * 0.50; 
        blobY += dy * 0.50;
        
        const speed = Math.sqrt(velocityX * velocityX + velocityY * velocityY);
        const maxSpeed = 50;
        const normalizedSpeed = Math.min(speed / maxSpeed, 1);
        
        const angle = Math.atan2(velocityY, velocityX);
        
        const stretchAmount = 1 + normalizedSpeed * 3;
        const compressAmount = 1 - normalizedSpeed * 0.5;
        
        const scaleX = Math.cos(angle) * Math.cos(angle) * (stretchAmount - 1) + compressAmount;
        const scaleY = Math.sin(angle) * Math.sin(angle) * (stretchAmount - 1) + compressAmount;
        const skewValue = Math.sin(2 * angle) * normalizedSpeed * 0.6;
        
        blob.style.left = `${blobX}px`;
        blob.style.top = `${blobY}px`;
        blob.style.transform = `
            translate(-50%, -50%)
            scale(${scaleX}, ${scaleY})
            rotate(${angle}rad)
            skewX(${skewValue}rad)
        `;
        
        velocityX *= 0.85;
        velocityY *= 0.85;
        
        requestAnimationFrame(animateBlob);
    }

    animateBlob();
});