let adesso = new Date();

let oraInizio = adesso.getHours();
let minutiInizio = adesso.getMinutes();

// aggiungo 15 minuti
let minutiFine = minutiInizio + 15;
let oraFine = oraInizio;

// se i minuti superano 59, faccio il riporto sull’ora
if (minutiFine >= 60) {
  minutiFine -= 60;
  oraFine += 1;
}

let messaggio = `Dalle ${oraInizio}:${minutiInizio.toString().padStart(2,"0")} 
alle ${oraFine}:${minutiFine.toString().padStart(2,"0")}`;

const paragrafo = document.getElementById("dataOra");
paragrafo.textContent = messaggio;





//---------------------

// crea una variabile minuti
//Con Math aggiungiamo un oggetto che contiene funzioni matematiche
//Floor significa paviamento quindi arrotonda per difetto. Prende quindi in considerazione solo la parte senza la virgola 
// tempo /60 ci permette di ottenere i minuti. 

//.toString().padStart(2, "0")
//serve per aggiungere uno zero avanti ai secondi in modo che invece di scrivere 15:0 scriverà 15:00
// let minuti = Math.floor(tempo/60); 
// console.log(minuti);

// let secondi = tempo%60;
// console.log(secondi);
// console.log(`${minuti} : ${secondi.toString().padStart(2, "0")}`);

//--------------------

//Countdown

let tempo = 900;
let timer;

//dichiarazione costante associate a p per visualizzarla 

const countdown = document.getElementById("countdown");

//dichiarazione costante bottone associato a bottone start html

const btnStart = document.getElementById("start")

//dichiarazione costante bottone associato a bottone restart html

const btnRestart = document.getElementById ("restart") 

//dichiarazione costante bottone associato a bottone pausa html

const btnPausa = document.getElementById("pausa")

//avvio della funzione di avvio countdown

function avviaCountdown() {
    clearInterval(timer);
timer = setInterval(() => {
    let minuti = Math.floor(tempo/60); 
console.log(minuti);

let secondi = tempo%60;
console.log(secondi);
    console.log(tempo);
    tempo--;
countdown.textContent = `${minuti}:${secondi.toString().padStart(2, "0")}`;
    if (tempo<0) {
    countdown.textContent = "Tempo scaduto!"
}
} ,1000
)
 btnStart.disabled = true;

}

//avvio della funzione di restart countdown 

function restartCountdown() {
  clearInterval(timer);
  tempo = 900;
  countdown.textContent = "15:00";
  btnStart.disabled = false; // riattiva il bottone Start
}

//avvio della funzione di pausa del countdown 

function pausaCountdown(){
    clearInterval(timer);
      btnStart.disabled = false;
}


//bottone che scatena l'evento di avvio del timer 

btnStart.addEventListener("click", avviaCountdown);

//bottone che scatena l'evento di restart del timer 

btnRestart.addEventListener("click", restartCountdown);

//bottone che mette in pausa il timer 

btnPausa.addEventListener("click", pausaCountdown)






