       
        const timerDisplay = document.getElementById('timerDisplay'); 
        const progressBar = document.getElementById('progressBar'); 
        const startBtn = document.getElementById('startBtn'); 
        const pauseBtn = document.getElementById('pauseBtn'); 
        const resetBtn = document.getElementById('resetBtn'); 
        const message = document.getElementById('message'); 
        const fireBackground = document.getElementById('fireBackground');
        
       
        const startTimeDisplay = document.getElementById('startTimeDisplay');
        const endTimeDisplay = document.getElementById('endTimeDisplay');
         
        let totalTime = 15 * 60; 
        let timeLeft = totalTime; 
        let timerInterval = null; 
        let isRunning = false; 
         
        function formatTime(seconds) { 
            const mins = Math.floor(seconds / 60); 
            const secs = seconds % 60; 
            return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`; 
        }

       
        function formatClockTime(date) {
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            return `${hours}:${minutes}`;
        }
         
       
        function updateDisplay() { 
            timerDisplay.textContent = formatTime(timeLeft); 
             
           
            const progressPercentage = (timeLeft / totalTime) * 100; 
            progressBar.style.width = `${progressPercentage}%`; 
             
            
            if (timeLeft <= 60) { 
                timerDisplay.style.textShadow = '0 0 20px #ff0000'; 
                progressBar.style.background = 'linear-gradient(to right, #ff0000, #ff4500)'; 
                message.textContent = "Tempo quasi scaduto!"; 
            } else if (timeLeft <= 300) { 
                timerDisplay.style.textShadow = '0 0 15px #ff8c00'; 
                progressBar.style.background = 'linear-gradient(to right, #ff8c00, #ff4500)'; 
                message.textContent = "Stai andando forte!"; 
            } else { 
                timerDisplay.style.textShadow = '0 0 15px #ff4500'; 
                progressBar.style.background = 'linear-gradient(to right, #ff4500, #ff8c00, #ffd700)'; 
                message.textContent = ""; 
            } 
        } 
         
         
        function startTimer() { 
            if (isRunning) return; 
             
           
            
            const now = new Date();
            
            if (!startTimeDisplay.textContent || startTimeDisplay.textContent === "--:--") {
                startTimeDisplay.textContent = formatClockTime(now);
            }
            
           
            const endTime = new Date(now.getTime() + timeLeft * 1000);
            endTimeDisplay.textContent = formatClockTime(endTime);

            isRunning = true; 
            startBtn.disabled = true; 
            pauseBtn.disabled = false; 
             
            timerInterval = setInterval(() => { 
                timeLeft--; 
                updateDisplay(); 
                 
                if (timeLeft <= 0) { 
                    clearInterval(timerInterval); 
                    timerDisplay.textContent = "00:00"; 
                    progressBar.style.width = "0%"; 
                    message.textContent = "Tempo scaduto!"; 
                    isRunning = false; 
                    startBtn.disabled = true; 
                    pauseBtn.disabled = true; 
                     
                    
                    timerDisplay.style.animation = "pulse 0.5s infinite alternate"; 
                    const style = document.createElement('style'); 
                    style.textContent = ` 
                        @keyframes pulse { 
                            from { transform: scale(1); } 
                            to { transform: scale(1.1); } 
                        } 
                    `; 
                    document.head.appendChild(style); 
                } 
            }, 1000); 
        } 
         
       
        function pauseTimer() { 
            if (!isRunning) return; 
             
            clearInterval(timerInterval); 
            isRunning = false; 
            startBtn.disabled = false; 
            pauseBtn.disabled = true; 
            message.textContent = "In pausa"; 
        } 
         
        
        function resetTimer() { 
            clearInterval(timerInterval); 
            timeLeft = totalTime; 
            isRunning = false; 
            startBtn.disabled = false; 
            pauseBtn.disabled = true; 
            message.textContent = ""; 
            timerDisplay.style.animation = ""; 
            
         
            startTimeDisplay.textContent = "--:--";
            endTimeDisplay.textContent = "--:--";
            
            updateDisplay(); 
        } 
         
       
        function createFireParticles() { 
            for (let i = 0; i < 100; i++) { 
                const particle = document.createElement('div'); 
                particle.classList.add('fire-particle'); 
                 
               
                particle.style.left = `${Math.random() * 100}%`; 
                 
                
                particle.style.animationDelay = `${Math.random() * 8}s`; 
              
                const size = 5 + Math.random() * 15; 
                particle.style.width = `${size}px`; 
                particle.style.height = `${size}px`; 
                 
                fireBackground.appendChild(particle); 
            } 
        } 
         
      
        startBtn.addEventListener('click', startTimer); 
        pauseBtn.addEventListener('click', pauseTimer); 
        resetBtn.addEventListener('click', resetTimer); 
         
       
        updateDisplay(); 
        createFireParticles(); 
