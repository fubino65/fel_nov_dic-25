//COSTANTI


//ELEMENTI DEL DOM
const spanInizioPausa = document.getElementById("inizio");
const spanFinePausa = document.getElementById("fine");
const siamoInPausa = document.querySelector("#pausa h3");


//ALTRE VARIABILI
let timeOptions ={
  hour: "2-digit",
  minute: "2-digit"
  
}


//GESTIONE DEGLI EVENTI

//il button fa partire gli orari di inizio e fine pausa
const startButton = document.getElementById("startBtn");
startButton.addEventListener("click", ()=>{
    inizioPausa = new Date();
    finePausa = new Date();
    finePausa.setMinutes(inizioPausa.getMinutes() +15);
    spanInizioPausa.textContent = inizioPausa.toLocaleTimeString("it-IT", timeOptions);
    spanFinePausa.textContent = finePausa.toLocaleTimeString("it-IT", timeOptions);
    siamoInPausa.classList.remove("nascosto");
})

//fiocchi di neve

function createSnowflake() {
  const snowflake = document.createElement("div");
  snowflake.classList.add("snowflake");
  snowflake.textContent = "❄"; // niente immagini!
  snowflake.style.left = Math.random() * 100 + "vw";
  snowflake.style.animationDuration = 3 + Math.random() * 5 + "s";
  document.body.appendChild(snowflake);

  setTimeout(() => snowflake.remove(), 8000);
}

// attivazione al click
document.querySelector("button").addEventListener("click", () => {
  setInterval(createSnowflake, 200);
});
