const codColoreP = document.getElementById('codiceColore');
const btnBlue = document.getElementById('blueBtn');
const btnRed = document.getElementById('redBtn');
const inizioPausaDOM = document.getElementById('inizioPausa');
const finePausaDOM = document.getElementById('finePausa');
const alertMessage = document.getElementById('alert-message');

const timerDisplay = document.getElementById('timer-display');
const progressCircle = document.getElementById('progress-circle');
const svgElement = document.getElementById('countdown-svg');
const formaElement = document.getElementById('forma'); // L'elemento contenitore

let intervalId = null;
let durataMs = 15 * 60 * 1000;
let tempoRimanenteMs = durataMs;
let ultimaVolta = null;
const circumference = 2 * Math.PI * 45;

progressCircle.style.strokeDasharray = circumference;

let inizioOra = new Date(); 
let finePausaOra = new Date(inizioOra.getTime() + durataMs); 

function formattaOra(data) {
    return data.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
}

function formattaTempoRimanente(ms) {
    const secondiTotali = Math.floor(ms / 1000);
    const minuti = Math.floor(secondiTotali / 60);
    const secondi = secondiTotali % 60;
    return `${String(minuti).padStart(2, '0')}:${String(secondi).padStart(2, '0')}`;
}

function aggiornaProgresso(ms) {
    const percentuale = ms / durataMs;
    const offset = circumference * (1 - percentuale);
    
    progressCircle.style.strokeDashoffset = offset;
    
    // Cambio colore dinamico basato sul tempo
    if (ms > durataMs * (2 / 3)) {
        progressCircle.className.baseVal = 'countdown-svg__progress progress--verde';
    } else if (ms > durataMs * (1 / 3)) {
        progressCircle.className.baseVal = 'countdown-svg__progress progress--giallo';
    } else {
        progressCircle.className.baseVal = 'countdown-svg__progress progress--rosso';
    }
}

function aggiornaCountdown() {
    const adesso = Date.now();
    const delta = adesso - ultimaVolta;
    tempoRimanenteMs -= delta;
    ultimaVolta = adesso;

    if (tempoRimanenteMs <= 0) {
        clearInterval(intervalId);
        intervalId = null;
        tempoRimanenteMs = 0;
        
        // CORREZIONE: Applica la classe al contenitore FORMA per far funzionare lampeggio e pulsazione
        formaElement.classList.add('allarme-pausa');
        
        btnBlue.disabled = true;
        alertMessage.classList.remove('pausa-alert--hidden');
    }
    
    aggiornaProgresso(tempoRimanenteMs);
    timerDisplay.textContent = formattaTempoRimanente(tempoRimanenteMs);
}


// Inizializzazione della visualizzazione
inizioPausaDOM.textContent = 'Inizio Pausa: ' + formattaOra(inizioOra);
finePausaDOM.textContent = 'Fine Pausa: ' + formattaOra(finePausaOra);

aggiornaProgresso(durataMs);
timerDisplay.textContent = formattaTempoRimanente(durataMs);

// Event Listener BLU (Avvio)
btnBlue.addEventListener('click', () => {
    if (intervalId === null) {
        ultimaVolta = Date.now();
        tempoRimanenteMs = durataMs; 
        
        // CORREZIONE: Rimuove la classe dal contenitore FORMA
        formaElement.classList.remove('allarme-pausa'); 
        
        alertMessage.classList.add('pausa-alert--hidden');
        aggiornaProgresso(durataMs);

        inizioOra = new Date(); 
        finePausaOra = new Date(inizioOra.getTime() + durataMs); 
        inizioPausaDOM.textContent = 'Inizio Pausa: ' + formattaOra(inizioOra);
        finePausaDOM.textContent = 'Fine Pausa: ' + formattaOra(finePausaOra);

        aggiornaCountdown();
        intervalId = setInterval(aggiornaCountdown, 10); 
        
        btnBlue.disabled = true;
    }
});

// Event Listener ROSSO (Stop/Reset)
btnRed.addEventListener('click', () => {
    clearInterval(intervalId);
    intervalId = null;
    tempoRimanenteMs = durataMs; 
    
    // CORREZIONE: Rimuove la classe dal contenitore FORMA
    formaElement.classList.remove('allarme-pausa');
    
    alertMessage.classList.add('pausa-alert--hidden');
    aggiornaProgresso(durataMs);

    btnBlue.disabled = false;

    timerDisplay.textContent = formattaTempoRimanente(tempoRimanenteMs);
});
