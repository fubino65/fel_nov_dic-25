class Parallax3DSystem {
    constructor() {
        this.sections = document.querySelectorAll('.parallax-section');
        this.navLinks = document.querySelectorAll('.nav-link');
        this.dots = document.querySelectorAll('.dot');
        this.currentSection = 0;
        this.isScrolling = false;
        this.scrollDelay = 1000;
        this.wheelTimeout = null;
        
        this.init();
    }
    
    init() {
        this.updateActiveSection(0);
        
        this.initEventListeners();
        
        this.initIntersectionObserver();
        
        this.initScrollHint();
    }
    
    initEventListeners() {
        window.addEventListener('wheel', (e) => this.handleWheel(e), { passive: false });
        
        window.addEventListener('keydown', (e) => this.handleKeys(e));
        
        this.navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const sectionIndex = parseInt(link.dataset.section);
                this.goToSection(sectionIndex);
            });
        });

        this.dots.forEach(dot => {
            dot.addEventListener('click', () => {
                const sectionIndex = parseInt(dot.dataset.section);
                this.goToSection(sectionIndex);
            });
        });
        
        this.initTouchEvents();
    }
    
    handleWheel(e) {
        if (this.isScrolling) return;
        
        if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
        
        e.preventDefault();
        
        const delta = Math.sign(e.deltaY);
        
        if (delta > 0) {
            this.nextSection();
        } else if (delta < 0) {
            this.prevSection();
        }
        
        this.isScrolling = true;
        setTimeout(() => {
            this.isScrolling = false;
        }, this.scrollDelay);
    }
    
    handleKeys(e) {
        if (this.isScrolling) return;
        
        switch(e.key) {
            case 'ArrowDown':
            case 'PageDown':
                e.preventDefault();
                this.nextSection();
                break;
            case 'ArrowUp':
            case 'PageUp':
                e.preventDefault();
                this.prevSection();
                break;
            case 'Home':
                e.preventDefault();
                this.goToSection(0);
                break;
            case 'End':
                e.preventDefault();
                this.goToSection(this.sections.length - 1);
                break;
        }
    }
    
    initTouchEvents() {
        let touchStartY = 0;
        let touchEndY = 0;
        
        document.addEventListener('touchstart', (e) => {
            touchStartY = e.changedTouches[0].screenY;
        }, { passive: true });
        
        document.addEventListener('touchend', (e) => {
            if (this.isScrolling) return;
            
            touchEndY = e.changedTouches[0].screenY;
            const delta = touchStartY - touchEndY;
            
            if (Math.abs(delta) > 50) { 
                if (delta > 0) {
                    this.nextSection();
                } else {
                    this.prevSection();
                }
                
                this.isScrolling = true;
                setTimeout(() => {
                    this.isScrolling = false;
                }, this.scrollDelay);
            }
        }, { passive: true });
    }
    
    nextSection() {
        if (this.currentSection < this.sections.length - 1) {
            this.goToSection(this.currentSection + 1);
        }
    }
    
    prevSection() {
        if (this.currentSection > 0) {
            this.goToSection(this.currentSection - 1);
        }
    }
    
    goToSection(index) {
        if (this.isScrolling || index < 0 || index >= this.sections.length) return;
        
        this.isScrolling = true;
        this.currentSection = index;
        
        this.updateActiveSection(index);
        
        this.updateNavigation(index);
        
        this.updateDots(index);
        
        this.updateScrollHint(index);
        
        this.playTransitionSound();
        
        setTimeout(() => {
            this.isScrolling = false;
        }, this.scrollDelay);
    }
    
    updateActiveSection(index) {
        this.sections.forEach((section, i) => {
            section.classList.remove('active', 'prev', 'next');
            
            if (i === index) {
                section.classList.add('active');
            } else if (i < index) {
                section.classList.add('prev');
            } else if (i > index) {
                section.classList.add('next');
            }
        });
    }
    
    updateNavigation(index) {
        this.navLinks.forEach(link => {
            link.classList.remove('active');
            if (parseInt(link.dataset.section) === index) {
                link.classList.add('active');
            }
        });
    }
    
    updateDots(index) {
        this.dots.forEach(dot => {
            dot.classList.remove('active');
            if (parseInt(dot.dataset.section) === index) {
                dot.classList.add('active');
            }
        });
    }
    
    initIntersectionObserver() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const sectionIndex = parseInt(entry.target.dataset.index);
                    
                    this.triggerSectionAnimations(sectionIndex);
                }
            });
        }, { threshold: 0.5 });
        
        this.sections.forEach(section => {
            observer.observe(section);
        });
    }
    
    triggerSectionAnimations(sectionIndex) {
        switch(sectionIndex) {
            case 2: 
                this.animateSkillBars();
                break;
            case 3: 
                this.animateProjectCards();
                break;
        }
    }
    
    animateSkillBars() {
        const skillBars = document.querySelectorAll('.skill-level');
        skillBars.forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0';
            
            setTimeout(() => {
                bar.style.transition = 'width 1.5s cubic-bezier(0.165, 0.84, 0.44, 1)';
                bar.style.width = width;
            }, 300);
        });
    }
    
    animateProjectCards() {
        const projectCards = document.querySelectorAll('.project-card');
        projectCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                card.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 200);
        });
    }
    
    initScrollHint() {
        this.updateScrollHint(0);
    }
    
    updateScrollHint(sectionIndex) {
        const scrollHint = document.querySelector('.scroll-hint');
        if (!scrollHint) return;
        
        if (sectionIndex === 0) {
            scrollHint.style.opacity = '1';
            scrollHint.style.pointerEvents = 'all';
        } else {
            scrollHint.style.opacity = '0';
            scrollHint.style.pointerEvents = 'none';
        }
    }
    
    playTransitionSound() {
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 300;
            oscillator.type = 'sine';
            gainNode.gain.value = 0.05;
            
            oscillator.start();
            gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.1);
            oscillator.stop(audioContext.currentTime + 0.1);
        } catch (e) {
            // Silently fail se AudioContext non è supportato
        }
    }

    initParallaxAnimations() {
    const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                this.animateSectionElements(entry.target);
            }
        });
    }, {
        threshold: 0.3,
        rootMargin: '0px 0px 0px 0px'
    });
    
    this.sections.forEach(section => {
        sectionObserver.observe(section);
    });
}

animateSectionElements(section) {
    if (section.hasAttribute('data-animated')) return;
    section.setAttribute('data-animated', 'true');
    
    const animatedElements = section.querySelectorAll('.animate-element:not(.animated)');
    
    animatedElements.forEach((element, index) => {
        const hasDelay = element.classList.contains('delay-1') || 
                        element.classList.contains('delay-2') || 
                        element.classList.contains('delay-3') || 
                        element.classList.contains('delay-4') || 
                        element.classList.contains('delay-5');
        
        const delay = hasDelay ? 0 : index * 200;
        
        setTimeout(() => {
            element.classList.add('animated');
        }, delay);
    });
}
}

document.addEventListener('DOMContentLoaded', () => {
    new Parallax3DSystem();
    
    const style = document.createElement('style');
    style.textContent = `
        .parallax-section {
            transition: transform 1.2s cubic-bezier(0.645, 0.045, 0.355, 1),
                       opacity 1.2s cubic-bezier(0.645, 0.045, 0.355, 1);
        }
        
        .scroll-hint {
            transition: opacity 0.5s ease;
        }
        
        .project-card {
            transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
    `;
    document.head.appendChild(style);
});

window.parallaxSystem = new Parallax3DSystem();