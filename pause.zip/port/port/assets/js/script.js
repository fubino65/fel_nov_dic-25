class LiquidGlassEffects {
    constructor() {
        this.init();
        this.initScrollAnimations();
    }
    
    init() {
        this.initTheme();
        
        this.initAnimations();
        
        this.initInteractions();
        
        this.initBackgroundParallax();
    }
    
    initTheme() {
        const savedTheme = localStorage.getItem('portfolio-theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        this.updateThemeUI(savedTheme);
        
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }
    }
    
    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.documentElement.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
        document.documentElement.setAttribute('data-theme', newTheme);
        
        setTimeout(() => {
            document.documentElement.style.transition = '';
        }, 500);
        

        localStorage.setItem('portfolio-theme', newTheme);

        this.updateThemeUI(newTheme);
        
        this.createThemeChangeEffect(newTheme);
    }
    
    updateThemeUI(theme) {
        const themeToggle = document.getElementById('themeToggle');
        if (!themeToggle) return;
        
        const icon = themeToggle.querySelector('i');
        const text = themeToggle.querySelector('.theme-text');
        
        if (theme === 'dark') {
            icon.className = 'fas fa-sun';
            text.textContent = 'Chiaro';
        } else {
            icon.className = 'fas fa-moon';
            text.textContent = 'Scuro';
        }
    }
    
    createThemeChangeEffect(theme) {
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: ${theme === 'dark' ? '#000' : '#fff'};
            z-index: 9999;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        `;
        
        document.body.appendChild(overlay);
        
        requestAnimationFrame(() => {
            overlay.style.opacity = '0.7';
            
            setTimeout(() => {
                overlay.style.opacity = '0';
                
                setTimeout(() => {
                    overlay.remove();
                }, 300);
            }, 300);
        });
    }
    
    initAnimations() {
        this.animateSkillBars();
        
        this.animateLiquidDrops();
        
        this.initGlassCardEffects();

        this.initButtonEffects();
    }
    
    animateSkillBars() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const skillBars = entry.target.querySelectorAll('[data-width]');
                skillBars.forEach((bar, index) => {
                    const width = bar.getAttribute('data-width');
                    
                    bar.style.width = '0';
                    
                    setTimeout(() => {
                        bar.style.transition = 'width 1.5s cubic-bezier(0.165, 0.84, 0.44, 1)';
                        bar.style.width = width;
                    }, index * 100);
                });
            }
        });
    }, { threshold: 0.3 });
    
    const skillsSection = document.querySelector('.section-3');
    if (skillsSection) observer.observe(skillsSection);
}
    
    animateLiquidDrops() {
        const createDrop = () => {
            const drop = document.createElement('div');
            drop.className = 'liquid-drop';
            drop.style.cssText = `
                position: fixed;
                width: ${10 + Math.random() * 15}px;
                height: ${10 + Math.random() * 15}px;
                background: var(--color-accent);
                border-radius: 50%;
                opacity: ${0.1 + Math.random() * 0.1};
                filter: blur(3px);
                pointer-events: none;
                z-index: 999;
            `;
            
            drop.style.left = `${Math.random() * 100}vw`;
            drop.style.top = '-20px';
            
            document.body.appendChild(drop);
            
            const animation = drop.animate([
                { 
                    transform: 'translateY(0) scale(1)',
                    opacity: drop.style.opacity 
                },
                { 
                    transform: `translateY(${window.innerHeight + 100}px) scale(${0.5 + Math.random() * 0.5})`,
                    opacity: '0' 
                }
            ], {
                duration: 2000 + Math.random() * 3000,
                easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
            });
            
            animation.onfinish = () => drop.remove();
        };
        
        setInterval(createDrop, 3000);
    }
    
    initGlassCardEffects() {
        const cards = document.querySelectorAll('.glass-card');
        
        cards.forEach(card => {
            card.addEventListener('mouseenter', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const reflex = document.createElement('div');
                reflex.className = 'dynamic-reflex';
                reflex.style.cssText = `
                    position: absolute;
                    width: 100px;
                    height: 100px;
                    background: radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%);
                    border-radius: 50%;
                    top: ${y - 50}px;
                    left: ${x - 50}px;
                    pointer-events: none;
                    z-index: 1;
                    transition: all 0.3s ease;
                `;
                
                card.appendChild(reflex);
                
                setTimeout(() => {
                    reflex.style.opacity = '0';
                    reflex.style.transform = 'scale(1.5)';
                    
                    setTimeout(() => reflex.remove(), 300);
                }, 100);
            });
            
            card.addEventListener('click', (e) => {
                this.createRippleEffect(e, card);
            });
        });
    }
    
    initButtonEffects() {
        const buttons = document.querySelectorAll('.liquid-glass-button');
        
        buttons.forEach(button => {
            button.addEventListener('mouseenter', () => {
                const effect = button.querySelector('.liquid-effect');
                if (!effect) {
                    const effect = document.createElement('span');
                    effect.className = 'liquid-effect';
                    effect.style.cssText = `
                        position: absolute;
                        top: 0;
                        left: -100%;
                        width: 100%;
                        height: 100%;
                        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
                        z-index: 1;
                    `;
                    button.appendChild(effect);
                    
                    requestAnimationFrame(() => {
                        effect.style.transition = 'transform 2s ease';
                        effect.style.transform = 'translateX(200%)';
                        
                        setTimeout(() => effect.remove(), 2000);
                    });
                }
            });
            
            button.addEventListener('click', (e) => {
                this.createRippleEffect(e, button);
            });
        });
    }
    
    createRippleEffect(event, element) {
        const ripple = document.createElement('span');
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
            position: absolute;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%);
            transform: scale(0);
            animation: ripple 0.6s linear;
            width: ${size}px;
            height: ${size}px;
            top: ${y}px;
            left: ${x}px;
            pointer-events: none;
            z-index: 1;
        `;
        
        element.appendChild(ripple);
        
        setTimeout(() => ripple.remove(), 600);
    }
    
    initInteractions() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });

        const projectsButton = document.getElementById('projects-button');
        if (projectsButton) {
            projectsButton.addEventListener('click', () => {
                // Usa il sistema di parallasse se disponibile
                if (typeof Parallax3DSystem !== 'undefined') {
                    const parallaxSystem = window.parallaxSystem;
                    if (parallaxSystem && parallaxSystem.goToSection) {
                        parallaxSystem.goToSection(3); // Sezione progetti è index 3
                    } else {
                        // Fallback: scroll normale alla sezione
                        const projectsSection = document.querySelector('.section-4');
                        if (projectsSection) {
                            projectsSection.scrollIntoView({ 
                                behavior: 'smooth',
                                block: 'start'
                            });
                        }
                    }
                }
            });
        }
        
        const contactForm = document.querySelector('.contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                
                const button = contactForm.querySelector('.submit-btn');
                const originalText = button.querySelector('.button-content span').textContent;
                
                button.querySelector('.button-content span').textContent = 'Invio in corso...';
                button.disabled = true;
                
                setTimeout(() => {
                    alert('Messaggio inviato con successo! Ti risponderò al più presto.');
                    contactForm.reset();
                    button.querySelector('.button-content span').textContent = originalText;
                    button.disabled = false;
                }, 1500);
            });
        }
        
        document.querySelectorAll('.project-link').forEach(link => {
            link.addEventListener('mouseenter', () => {
                link.style.transform = 'translateX(5px)';
            });
            
            link.addEventListener('mouseleave', () => {
                link.style.transform = 'translateX(0)';
            });
        });
    }
    
    initBackgroundParallax() {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * 0.5;
            
            document.querySelectorAll('.section-bg').forEach(bg => {
                bg.style.transform = `translateZ(-1px) scale(1.2) translateY(${rate * 0.3}px)`;
            });
        });
        
        document.addEventListener('mousemove', (e) => {
            const x = (e.clientX / window.innerWidth) * 20 - 10;
            const y = (e.clientY / window.innerHeight) * 20 - 10;
            
            document.querySelectorAll('.blob').forEach((blob, index) => {
                const multiplier = (index + 1) * 0.5;
                blob.style.transform = `translate(${x * multiplier}px, ${y * multiplier}px)`;
            });
        });
    }

    initScrollAnimations() {
    const observerOptions = {
        threshold: 0.15, 
        rootMargin: '0px 0px -50px 0px' 
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                
                setTimeout(() => {
                    observer.unobserve(entry.target);
                }, 1000);
            }
        });
    }, observerOptions);
    
    setTimeout(() => {
        document.querySelectorAll('.animate-element').forEach(element => {
            observer.observe(element);
        });
    }, 500);
}
}

document.addEventListener('DOMContentLoaded', () => {
    new LiquidGlassEffects();

    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .liquid-drop {
            animation: dropFall 3s ease-out forwards;
        }
        
        @keyframes dropFall {
            to {
                transform: translateY(100vh);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
});

